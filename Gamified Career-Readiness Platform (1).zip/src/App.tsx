import { useEffect, useState, type ReactNode } from "react";

type Page =
  | "Home"
  | "Dashboard"
  | "Practice"
  | "Head-to-Head"
  | "AI Coach"
  | "Leaderboard"
  | "Profile"
  | "Character"
  | "Avatar Shop";

type EquippedItems = {
  outfit: string;
  accessory: string;
  background: string;
};

type ProfileData = {
  name: string;
  avatar: string;
  schoolMajor: string;
  locationBio: string;
};

type IconName =
  | "home"
  | "grid"
  | "play"
  | "versus"
  | "spark"
  | "trophy"
  | "user"
  | "gavel"
  | "bolt"
  | "fire"
  | "clock"
  | "arrow"
  | "check"
  | "mic"
  | "video"
  | "text"
  | "target"
  | "star"
  | "menu"
  | "bell"
  | "close";

const navItems: { label: Page; icon: IconName }[] = [
  { label: "Home", icon: "home" },
  { label: "Dashboard", icon: "grid" },
  { label: "Practice", icon: "play" },
  { label: "Head-to-Head", icon: "versus" },
  { label: "AI Coach", icon: "spark" },
  { label: "Leaderboard", icon: "trophy" },
  { label: "Profile", icon: "user" },
];

const iconPaths: Record<IconName, ReactNode> = {
  home: <><path d="m3 10 9-7 9 7" /><path d="M5 9v11h14V9M9 20v-7h6v7" /></>,
  grid: <><rect x="3" y="3" width="7" height="7" rx="2" /><rect x="14" y="3" width="7" height="7" rx="2" /><rect x="3" y="14" width="7" height="7" rx="2" /><rect x="14" y="14" width="7" height="7" rx="2" /></>,
  play: <><circle cx="12" cy="12" r="9" /><path d="m10 8 6 4-6 4Z" /></>,
  versus: <><path d="M8 8h8M8 16h8M5 5l3 3-3 3M19 13l-3 3 3 3" /></>,
  spark: <><path d="m12 3 1.4 4.2L18 9l-4.6 1.8L12 15l-1.4-4.2L6 9l4.6-1.8Z" /><path d="m18.5 15 .8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8Z" /></>,
  trophy: <><path d="M8 4h8v5a4 4 0 0 1-8 0Z" /><path d="M12 13v4M8 21h8M9 17h6M8 6H4v2a4 4 0 0 0 4 4M16 6h4v2a4 4 0 0 1-4 4" /></>,
  user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
  gavel: <><path d="m14 5 5 5M12 7l5 5M15.5 3.5l-5 5 6 6 5-5ZM12 12 4 20M2 21h8" /></>,
  bolt: <path d="m13 2-8 12h7l-1 8 8-12h-7Z" />,
  fire: <path d="M12 22c4 0 7-3 7-7 0-3-2-6-5-9 0 3-2 5-3 6 0-4-2-7-4-9 0 5-3 7-3 12 0 4 3 7 8 7Z" />,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  arrow: <><path d="M5 12h14M14 7l5 5-5 5" /></>,
  check: <path d="m5 12 4 4L19 6" />,
  mic: <><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3M9 21h6" /></>,
  video: <><rect x="3" y="6" width="13" height="12" rx="2" /><path d="m16 10 5-3v10l-5-3Z" /></>,
  text: <><path d="M5 5h14M12 5v14M8 19h8" /></>,
  target: <><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5" /><circle cx="12" cy="12" r="1" /></>,
  star: <path d="m12 3 2.7 5.5 6 .9-4.4 4.2 1 6-5.3-2.8-5.3 2.8 1-6-4.4-4.2 6-.9Z" />,
  menu: <><path d="M4 7h16M4 12h16M4 17h16" /></>,
  bell: <><path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" /></>,
  close: <><path d="m6 6 12 12M18 6 6 18" /></>,
};

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {iconPaths[name]}
    </svg>
  );
}

function Button({
  children,
  variant = "primary",
  onClick,
  className = "",
}: {
  children: ReactNode;
  variant?: "primary" | "secondary" | "ghost";
  onClick?: () => void;
  className?: string;
}) {
  return <button className={`btn btn-${variant} ${className}`} onClick={onClick}>{children}</button>;
}

function Logo() {
  return (
    <div className="logo">
      <div className="logo-mark"><span>P</span></div>
      <span>PITCH</span>
    </div>
  );
}

function Sidebar({ page, onNavigate, open, onClose, profile }: { page: Page; onNavigate: (page: Page) => void; open: boolean; onClose: () => void; profile: ProfileData }) {
  return (
    <aside className={`sidebar ${open ? "sidebar-open" : ""}`}>
      <div className="sidebar-head">
        <Logo />
        <button className="icon-button mobile-only" onClick={onClose} aria-label="Close menu"><Icon name="close" /></button>
      </div>
      <nav className="nav-list">
        {navItems.map((item) => (
          <button
            key={item.label}
            className={`nav-item ${page === item.label ? "nav-active" : ""}`}
            onClick={() => { onNavigate(item.label); onClose(); }}
          >
            <Icon name={item.icon} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
      <div className="sidebar-footer">
        <div className="mini-level">
          <div className="avatar avatar-small">{profile.avatar.startsWith("http") ? <img src={profile.avatar} alt="" /> : profile.avatar}</div>
          <div className="grow">
            <div className="mini-name">{profile.name}</div>
            <div className="mini-label">Level 8 · Rising Pro</div>
          </div>
          <Icon name="arrow" size={16} />
        </div>
        <div className="xp-track"><div className="xp-fill" /></div>
        <div className="xp-copy"><span>2,450 XP</span><span>3,000 XP</span></div>
      </div>
    </aside>
  );
}

function Stat({ icon, value, label, tone }: { icon: IconName; value: string; label: string; tone: string }) {
  return (
    <div className="stat-card">
      <div className={`stat-icon ${tone}`}><Icon name={icon} /></div>
      <div><div className="stat-value">{value}</div><div className="muted">{label}</div></div>
    </div>
  );
}

function SectionTitle({ eyebrow, title, action }: { eyebrow?: string; title: string; action?: ReactNode }) {
  return (
    <div className="section-title">
      <div>
        {eyebrow && <div className="eyebrow">{eyebrow}</div>}
        <div className="heading">{title}</div>
      </div>
      {action}
    </div>
  );
}

const categories = [
  { icon: "user" as IconName, title: "Interviews", desc: "Answer the questions that matter", count: "24 scenarios", tone: "purple" },
  { icon: "spark" as IconName, title: "Networking", desc: "Make meaningful connections", count: "18 scenarios", tone: "cyan" },
  { icon: "versus" as IconName, title: "Teamwork", desc: "Collaborate under pressure", count: "20 scenarios", tone: "green" },
  { icon: "trophy" as IconName, title: "Leadership", desc: "Step up and lead the room", count: "16 scenarios", tone: "orange" },
  { icon: "bolt" as IconName, title: "Conflict", desc: "Navigate difficult moments", count: "21 scenarios", tone: "pink" },
  { icon: "target" as IconName, title: "Workplace Mistakes", desc: "Recover quickly and own it", count: "15 scenarios", tone: "yellow" },
];

function Dashboard({ onNavigate, equipped }: { onNavigate: (page: Page) => void; equipped: EquippedItems }) {
  return (
    <>
      <section className="welcome">
        <div>
          <div className="eyebrow">MONDAY, MAY 19</div>
          <div className="display">Ready to step up, Jordan?</div>
          <p className="subcopy">Your next opportunity won’t wait. Let’s sharpen your edge.</p>
        </div>
        <div className="stats">
          <Stat icon="bolt" value="2,450" label="Total XP" tone="lime" />
          <Stat icon="fire" value="12 days" label="Current streak" tone="orange" />
          <Stat icon="trophy" value="#184" label="Weekly rank" tone="purple" />
        </div>
      </section>

      <section className="daily-card">
        <div className="daily-glow" />
        <div className="daily-content">
          <div className="daily-top">
            <span className="live-pill"><span className="live-dot" /> DAILY PITCH</span>
            <span className="time-left"><Icon name="clock" size={17} /> 11h 42m left</span>
          </div>
          <div className="daily-body">
            <div className="daily-copy">
              <div className="challenge-label">TODAY’S CHALLENGE</div>
              <div className="daily-title">The Wrong Deck</div>
              <p>You’re an intern and realize your team just sent a major client the wrong presentation. Everyone’s in a meeting. What do you do?</p>
              <div className="skill-tags">
                <span>WORKPLACE MISTAKES</span><span>PROFESSIONALISM</span><span>60 SEC</span>
              </div>
            </div>
            <div className="pitch-action">
              <div className="timer-ring">
                <div className="timer-inner"><span>60</span><small>SEC</small></div>
              </div>
              <Button onClick={() => onNavigate("Practice")}>Start Today’s Pitch <Icon name="arrow" size={18} /></Button>
              <span className="reward"><Icon name="bolt" size={15} /> +150 XP on completion</span>
            </div>
          </div>
        </div>
      </section>

      <section className="avatar-reward-card">
        <div className="avatar-card-character"><AvatarCharacter compact {...equipped} /></div>
        <div className="avatar-reward-copy">
          <div className="eyebrow">YOUR PITCH CHARACTER</div>
          <div className="heading">Your progress has a look now.</div>
          <p>Complete one more scenario to earn 40 Coins. New outfits, accessories, poses, and profile frames are waiting.</p>
        </div>
        <div className="coin-balance"><Icon name="bolt" /><div><strong>1,240</strong><span>PITCH COINS</span></div></div>
        <Button variant="secondary" onClick={() => onNavigate("Character")}>Customize <Icon name="arrow" /></Button>
      </section>

      <section className="content-section">
        <SectionTitle
          eyebrow="CHOOSE YOUR ARENA"
          title="Practice by category"
          action={<Button variant="ghost">View all <Icon name="arrow" size={16} /></Button>}
        />
        <div className="category-grid">
          {categories.map((category) => (
            <button className="category-card" key={category.title} onClick={() => onNavigate("Practice")}>
              <div className={`category-icon ${category.tone}`}><Icon name={category.icon} /></div>
              <div className="category-title">{category.title}</div>
              <p>{category.desc}</p>
              <div className="category-meta"><span>{category.count}</span><Icon name="arrow" size={17} /></div>
            </button>
          ))}
        </div>
      </section>

      <section className="lower-grid">
        <div className="panel">
          <SectionTitle eyebrow="YOUR PROGRESS" title="This week" action={<span className="trend">↑ 18%</span>} />
          <div className="chart">
            {[42, 64, 48, 78, 58, 86, 72].map((height, index) => (
              <div className="bar-wrap" key={index}><div className={`bar ${index === 5 ? "bar-hot" : ""}`} style={{ height: `${height}%` }} /><span>{["M","T","W","T","F","S","S"][index]}</span></div>
            ))}
          </div>
        </div>
        <div className="panel">
          <SectionTitle eyebrow="RECENT FEEDBACK" title="Your coach says" />
          <div className="coach-note">
            <div className="coach-avatar"><Icon name="spark" /></div>
            <div>
              <p>“Strong opening, Jordan. Next time, pause before your key point—it’ll land with more confidence.”</p>
              <span>Interview Practice · 2h ago</span>
            </div>
          </div>
          <div className="score-row">
            {["Clarity 86", "Confidence 79", "Adaptability 92"].map((score) => <span key={score}>{score}</span>)}
          </div>
        </div>
      </section>
    </>
  );
}

function Practice({ initialTitle = "Practice Arena" }: { initialTitle?: string }) {
  const [started, setStarted] = useState(false);
  const [time, setTime] = useState(60);
  const [mode, setMode] = useState<"video" | "mic" | "text">("video");

  useEffect(() => {
    if (!started || time <= 0) return;
    const timer = window.setInterval(() => setTime((value) => value - 1), 1000);
    return () => window.clearInterval(timer);
  }, [started, time]);

  return (
    <div className="page-stack">
      <SectionTitle eyebrow="SOLO TRAINING" title={initialTitle} />
      <div className="arena">
        <div className="arena-top">
          <span className="live-pill">WORKPLACE MISTAKES</span>
          <div className={`countdown ${time <= 10 ? "urgent" : ""}`}><Icon name="clock" /> 00:{String(time).padStart(2, "0")}</div>
        </div>
        <div className="arena-prompt">You catch a mistake in a report your manager is about to present to the executive team. They have five minutes. What do you do?</div>
        <p className="arena-hint">Be specific. Show ownership, composure, and clear next steps.</p>
        <div className="mode-switch">
          {(["video", "mic", "text"] as const).map((item) => (
            <button key={item} className={mode === item ? "mode-active" : ""} onClick={() => setMode(item)}>
              <Icon name={item} /><span>{item === "mic" ? "Audio" : item[0].toUpperCase() + item.slice(1)}</span>
            </button>
          ))}
        </div>
        <div className="response-stage">
          {mode === "video" && <><div className="camera-orb"><Icon name="video" size={34} /></div><span>Camera preview</span></>}
          {mode === "mic" && <><div className="wave">{[1,2,3,4,5,6,7].map((n) => <i key={n} />)}</div><span>Microphone ready</span></>}
          {mode === "text" && <textarea aria-label="Type your response" placeholder="Type how you would respond..." />}
        </div>
        <Button onClick={() => { setStarted(!started); if (time === 0) setTime(60); }} className="arena-button">
          <Icon name={started ? "check" : mode} /> {started ? "Submit response" : "Start response"}
        </Button>
      </div>
      <div className="loop-strip">
        {["Get Scenario", "Think", "Respond", "Get Judged", "AI Feedback", "Earn XP"].map((step, index) => (
          <div key={step}><span>{index + 1}</span>{step}{index < 5 && <Icon name="arrow" size={15} />}</div>
        ))}
      </div>
    </div>
  );
}

function Home({ onNavigate }: { onNavigate: (page: Page) => void }) {
  const featureCards: { icon: IconName; title: string; copy: string; tone: string; page: Page }[] = [
    { icon: "play", title: "Practice", copy: "Try realistic interview and workplace scenarios.", tone: "lime", page: "Practice" },
    { icon: "versus", title: "Head-to-Head", copy: "Compete against another student in timed challenges.", tone: "purple", page: "Head-to-Head" },
    { icon: "spark", title: "AI Coach", copy: "Practice conversations with recruiters, managers, clients, and coworkers.", tone: "cyan", page: "AI Coach" },
    { icon: "target", title: "Track Your Growth", copy: "See your communication, problem-solving, confidence, and leadership progress.", tone: "orange", page: "Profile" },
    { icon: "trophy", title: "Compete & Connect", copy: "Earn XP, badges, streaks, and challenge friends.", tone: "pink", page: "Leaderboard" },
  ];
  const steps = ["Choose a scenario", "Prepare", "Respond", "Get feedback", "Improve"];
  const scenarios = [
    { tag: "LEADERSHIP", copy: "Your manager gives you an unrealistic deadline.", icon: "clock" as IconName },
    { tag: "INTERVIEWS", copy: "A recruiter asks why you want the job.", icon: "user" as IconName },
    { tag: "TEAMWORK", copy: "Your teammate isn’t doing their part.", icon: "versus" as IconName },
  ];

  return (
    <div className="home-page">
      <section className="home-hero">
        <div className="home-hero-copy">
          <div className="hero-kicker"><span className="live-dot" /> CAREER SKILLS. GAME ON.</div>
          <div className="home-hero-title">Build career skills by <em>actually practicing them.</em></div>
          <p className="home-hero-subtitle">Practice interviews, handle real workplace situations, compete with friends, and build confidence before you step into the real world.</p>
          <div className="hero-actions">
            <Button onClick={() => onNavigate("Practice")}>Start Practicing <Icon name="arrow" /></Button>
            <Button variant="secondary" onClick={() => document.getElementById("pitch-features")?.scrollIntoView({ behavior: "smooth" })}>Explore PITCH</Button>
          </div>
          <div className="hero-proof">
            <div className="proof-avatars"><span>JL</span><span>MK</span><span>ER</span></div>
            <div><strong>10,000+ practice rounds</strong><span>completed by students this month</span></div>
          </div>
        </div>
        <div className="home-demo">
          <div className="demo-header">
            <span className="live-pill"><span className="live-dot" /> LIVE PRACTICE</span>
            <span className="countdown"><Icon name="clock" size={17} /> 00:42</span>
          </div>
          <div className="demo-category">WORKPLACE SCENARIO</div>
          <div className="demo-question">Your team sent a client the wrong presentation. What do you do?</div>
          <div className="demo-response">
            <div className="demo-person"><div className="avatar avatar-large">JL</div><span>YOUR RESPONSE</span></div>
            <div className="demo-wave">{[1,2,3,4,5,6,7,8,9,10,11,12].map((item) => <i key={item} />)}</div>
          </div>
          <div className="demo-score">
            <div><Icon name="spark" /><span><small>COACH SCORE</small><strong>86</strong></span></div>
            <div className="score-meter"><i /></div>
            <span>Clear, calm, and action-oriented</span>
          </div>
        </div>
      </section>

      <section className="home-section" id="pitch-features">
        <div className="home-section-head">
          <div><div className="eyebrow">ONE PLATFORM. EVERY SKILL.</div><div className="home-section-title">What can you do on PITCH?</div></div>
          <p>Build the skills employers look for through practice that feels real—not another lesson to click through.</p>
        </div>
        <div className="feature-grid">
          {featureCards.map((feature, index) => (
            <button className={`feature-card ${index === 0 ? "feature-primary" : ""}`} key={feature.title} onClick={() => onNavigate(feature.page)}>
              <div className={`category-icon ${feature.tone}`}><Icon name={feature.icon} /></div>
              <div className="feature-title">{feature.title}</div>
              <p>{feature.copy}</p>
              <span>Explore feature <Icon name="arrow" size={16} /></span>
            </button>
          ))}
        </div>
      </section>

      <section className="home-section how-section">
        <div className="how-intro">
          <div className="eyebrow">FROM PROMPT TO PROGRESS</div>
          <div className="home-section-title">How PITCH works</div>
          <p>No lectures. No perfect script. Just a simple loop that helps you get better every time you play.</p>
          <Button onClick={() => onNavigate("Practice")}>Try a practice round <Icon name="arrow" /></Button>
        </div>
        <div className="steps-track">
          {steps.map((step, index) => (
            <div className="home-step" key={step}>
              <div><span>{String(index + 1).padStart(2, "0")}</span><Icon name={index === 0 ? "target" : index === 1 ? "clock" : index === 2 ? "mic" : index === 3 ? "spark" : "bolt"} /></div>
              <strong>{step}</strong>
              {index < steps.length - 1 && <Icon name="arrow" size={17} />}
            </div>
          ))}
        </div>
      </section>

      <section className="home-section">
        <div className="home-section-head">
          <div><div className="eyebrow">SCENARIOS THAT MATTER</div><div className="home-section-title">Train for real life</div></div>
          <p>Practice the moments you can’t predict, so you know how to respond when they happen.</p>
        </div>
        <div className="scenario-grid">
          {scenarios.map((scenario, index) => (
            <button className="real-scenario" key={scenario.tag} onClick={() => onNavigate("Practice")}>
              <div className="scenario-number">0{index + 1}</div>
              <div className="scenario-icon"><Icon name={scenario.icon} /></div>
              <span>{scenario.tag}</span>
              <div>{scenario.copy}</div>
              <p>How would you respond?</p>
              <Icon name="arrow" />
            </button>
          ))}
        </div>
      </section>

      <section className="home-cta">
        <div className="cta-badge"><Icon name="bolt" /></div>
        <div className="eyebrow">YOUR MOVE</div>
        <div className="home-section-title">Your next opportunity won’t come with a script.<br />Practice for it.</div>
        <Button onClick={() => onNavigate("Practice")}>Start Your First PITCH <Icon name="arrow" /></Button>
        <div className="cta-note"><Icon name="check" size={15} /> No experience needed <span /> <Icon name="check" size={15} /> Start in under a minute</div>
      </section>
    </div>
  );
}

const gameDimensions = ["Communication", "Problem Solving", "Professionalism", "Adaptability", "Clarity"];
const demoOpponents = [
  { name: "Maya", initials: "MK", level: 9, style: "Strategic communicator" },
  { name: "Eli", initials: "ER", level: 8, style: "Calm problem solver" },
  { name: "Sofia", initials: "ST", level: 10, style: "Confident leader" },
  { name: "Noah", initials: "NB", level: 7, style: "Quick thinker" },
];
const matchScenarios = [
  "Your manager gives you an unrealistic deadline for a high-stakes project. How do you respond?",
  "A teammate takes credit for your idea during a client presentation. What do you do next?",
  "A client rejects your team's strongest proposal with no explanation. How do you move forward?",
];

function HeadToHead() {
  const [phase, setPhase] = useState<"intro" | "prep" | "respond" | "opponent" | "scoring" | "results">("intro");
  const [opponent, setOpponent] = useState(demoOpponents[0]);
  const [scenario, setScenario] = useState(matchScenarios[0]);
  const [time, setTime] = useState(15);
  const [response, setResponse] = useState("");
  const [responseMode, setResponseMode] = useState<"text" | "mic">("text");
  const [revealedScores, setRevealedScores] = useState(0);
  const [round, setRound] = useState(3);

  useEffect(() => {
    if ((phase !== "prep" && phase !== "respond") || time <= 0) return;
    const timer = window.setInterval(() => setTime((value) => value - 1), 1000);
    return () => window.clearInterval(timer);
  }, [phase, time]);

  useEffect(() => {
    if (time > 0) return;
    if (phase === "prep") { setPhase("respond"); setTime(60); }
    if (phase === "respond") submitResponse();
  }, [time, phase]);

  useEffect(() => {
    if (phase !== "opponent") return;
    const timer = window.setTimeout(() => { setPhase("scoring"); setRevealedScores(0); }, 2200);
    return () => window.clearTimeout(timer);
  }, [phase]);

  useEffect(() => {
    if (phase !== "scoring") return;
    if (revealedScores >= gameDimensions.length) {
      const finish = window.setTimeout(() => setPhase("results"), 900);
      return () => window.clearTimeout(finish);
    }
    const reveal = window.setTimeout(() => setRevealedScores((value) => value + 1), 550);
    return () => window.clearTimeout(reveal);
  }, [phase, revealedScores]);

  const responseDepth = Math.min(response.length / 180, 1);
  const solutionBonus = /plan|propose|solution|next step|recommend|clarif/i.test(response) ? 0.45 : 0;
  const ownershipBonus = /responsib|own|apolog|i would|i'll/i.test(response) ? 0.35 : 0;
  const playerScores = [8.1 + responseDepth * .6, 8.2 + solutionBonus + responseDepth * .35, 8.3 + ownershipBonus, 8.0 + solutionBonus, 8.2 + responseDepth * .8].map((score) => Math.min(score, 9.8));
  const opponentScores = opponent.name === "Sofia" ? [9.1, 8.9, 9.2, 8.8, 9.1] : opponent.name === "Maya" ? [9.0, 8.8, 9.1, 8.7, 9.2] : [8.5, 8.7, 8.6, 8.9, 8.4];
  const playerTotal = playerScores.reduce((sum, score) => sum + score, 0) / playerScores.length;
  const opponentTotal = opponentScores.reduce((sum, score) => sum + score, 0) / opponentScores.length;
  const result = playerTotal > opponentTotal ? "VICTORY" : playerTotal < opponentTotal ? "TOUGH LOSS" : "DRAW";

  function beginMatch() { setPhase("prep"); setTime(15); }
  function submitResponse() { setPhase("opponent"); setTime(0); }
  function newMatch() {
    const nextOpponent = demoOpponents[(demoOpponents.indexOf(opponent) + 1 + Math.floor(Math.random() * 2)) % demoOpponents.length];
    setOpponent(nextOpponent);
    setScenario(matchScenarios[Math.floor(Math.random() * matchScenarios.length)]);
    setResponse("");
    setRound((value) => value + 1);
    setRevealedScores(0);
    setPhase("intro");
  }

  return (
    <div className="page-stack playable-match">
      <div className="match-titlebar"><div><div className="eyebrow">ROUND {String(round).padStart(2, "0")} <span /> HEAD-TO-HEAD</div><div className="display">{phase === "results" ? result : "One scenario. Two responses."}</div></div><span className="online"><i /> LIVE MATCH</span></div>

      {phase === "intro" && <>
        <div className="matchup-intro">
          <div className="matchup-player"><div className="avatar avatar-xl">JL</div><span>YOU</span><strong>Jordan</strong><small>Level 8 · Rising Pro</small></div>
          <div className="matchup-vs"><span>RANKED MATCH</span><strong>VS</strong><small>Matched by skill</small></div>
          <div className="matchup-player"><div className="avatar avatar-xl avatar-alt">{opponent.initials}</div><span>OPPONENT</span><strong>{opponent.name}</strong><small>Level {opponent.level} · {opponent.style}</small></div>
        </div>
        <div className="scenario-reveal"><div><span>SHARED SCENARIO</span><strong>{scenario}</strong><p>You both get 15 seconds to prepare and 60 seconds to respond.</p></div><Button onClick={beginMatch}>Reveal & Start <Icon name="bolt" /></Button></div>
      </>}

      {(phase === "prep" || phase === "respond") && <div className="play-round">
        <div className="round-status"><span>{phase === "prep" ? "PREP TIME" : "YOUR RESPONSE"}</span><div className={`giant-timer ${time <= 10 ? "urgent" : ""}`}>00:{String(time).padStart(2, "0")}</div><small>{phase === "prep" ? "Think through your approach" : "Make your case clearly"}</small></div>
        <div className="active-scenario"><span>CURRENT SCENARIO</span><div>{scenario}</div></div>
        {phase === "prep" ? <div className="prep-guide">{["Identify the core problem", "Choose a professional response", "End with a clear next step"].map((step, index) => <div key={step}><span>{index + 1}</span>{step}</div>)}</div> : <>
          <div className="response-mode-tabs"><button className={responseMode === "text" ? "active" : ""} onClick={() => setResponseMode("text")}><Icon name="text" /> Type response</button><button className={responseMode === "mic" ? "active" : ""} onClick={() => setResponseMode("mic")}><Icon name="mic" /> Record response</button></div>
          {responseMode === "text" ? <textarea className="match-response-input" value={response} onChange={(event) => setResponse(event.target.value)} placeholder="How would you handle this situation? Be specific about what you would say and do..." /> : <div className="record-response"><div className="camera-orb"><Icon name="mic" /></div><strong>Microphone ready</strong><span>Press submit when you finish your response</span></div>}
          <div className="response-submit"><span>{response.length} characters · Aim for a focused 45–60 second answer</span><Button onClick={submitResponse}>Submit Response <Icon name="arrow" /></Button></div>
        </>}
      </div>}

      {phase === "opponent" && <div className="opponent-reveal"><div className="avatar avatar-profile avatar-alt">{opponent.initials}</div><div className="eyebrow">OPPONENT RESPONSE</div><div className="heading">{opponent.name} is responding...</div><div className="audio-bars">{[1,2,3,4,5,6,7,8,9].map((item) => <i key={item} />)}</div><p>“I’d acknowledge the urgency, clarify which outcomes are essential, and propose a realistic phased delivery...”</p></div>}

      {phase === "scoring" && <div className="score-reveal-stage"><div className="reveal-label">ANALYZING BOTH RESPONSES</div><div className="display">Scores are coming in</div><div className="dimension-reveals">{gameDimensions.map((dimension, index) => <div className={index < revealedScores ? "dimension-visible" : ""} key={dimension}><span>{dimension}</span><div><i style={{ width: `${playerScores[index] * 10}%` }} /></div><strong>{index < revealedScores ? playerScores[index].toFixed(1) : "—"}</strong><div><i style={{ width: `${opponentScores[index] * 10}%` }} /></div><strong>{index < revealedScores ? opponentScores[index].toFixed(1) : "—"}</strong></div>)}</div><div className="score-key"><span><i /> Jordan</span><span><i /> {opponent.name}</span></div></div>}

      {phase === "results" && <div className="game-results">
        <div className="result-banner"><Icon name={result === "VICTORY" ? "trophy" : "target"} /><span>{result}</span><strong>{playerTotal.toFixed(1)} <small>vs</small> {opponentTotal.toFixed(1)}</strong><p>{result === "VICTORY" ? `You edged out ${opponent.name} with a clearer action plan.` : `${opponent.name} led with slightly stronger clarity. You kept it close.`}</p></div>
        <div className="results-breakdown"><div className="heading">Dimension breakdown</div>{gameDimensions.map((dimension, index) => <div className="result-dimension" key={dimension}><span>{dimension}</span><div className="dual-bars"><i style={{ width: `${playerScores[index] * 10}%` }} /><i style={{ width: `${opponentScores[index] * 10}%` }} /></div><strong>{playerScores[index].toFixed(1)} / {opponentScores[index].toFixed(1)}</strong></div>)}</div>
        <div className="result-coaching"><div><div className="post-icon"><Icon name="star" /></div><span>WHAT WORKED</span><strong>Solution-focused ownership</strong><p>You acknowledged the pressure and offered a concrete path forward.</p></div><div><div className="post-icon"><Icon name="target" /></div><span>WHAT COULD IMPROVE</span><strong>Lead with the business impact</strong><p>Name the risk sooner, then make your recommendation confidently.</p></div></div>
        <div className="next-match-bar"><div><span>+100 XP · +60 COINS</span><strong>Ready for another opponent?</strong></div><Button onClick={newMatch}>Find New Match <Icon name="arrow" /></Button></div>
      </div>}
    </div>
  );
}

const coachPersonas = [
  { name: "Hiring Manager", context: "Behavioral interview", opening: ["Thanks for meeting with me. Tell me about a time you had to lead through uncertainty.", "Let's start with a challenge: describe a decision you made without complete information."] },
  { name: "Coworker", context: "Team collaboration", opening: ["Hey, I noticed our parts of the project aren't lining up. Can we talk through it?", "I'm worried we're going to miss the handoff. What do you think we should do?"] },
  { name: "Client", context: "Client conversation", opening: ["This isn't what we expected from the brief. Help me understand what happened.", "We're concerned about the latest work. What can your team do to fix this?"] },
  { name: "Professor", context: "Office hours", opening: ["I saw your message about the deadline. Walk me through what's going on.", "You wanted feedback on your project direction. What are you trying to accomplish?"] },
  { name: "Recruiter", context: "Job interview", opening: ["What made you interested in this role and our company?", "Give me the quick version: what would you bring to this team?"] },
  { name: "AI Recruiter", context: "Screening call · networking", opening: ["Hi Jordan, I have fifteen minutes. What are you hoping to explore in your next role?", "I found your profile through our student network. Tell me what kind of problems energize you."] },
  { name: "Manager Check-in", context: "Weekly 1:1 · performance", opening: ["Let's use our check-in to talk about what's working and where you're blocked.", "I want to discuss your progress this week. How do you think things are going?"] },
  { name: "Difficult Coworker", context: "Workplace conflict", opening: ["I don't think your approach is going to work, and we don't have time to debate it.", "I already handled my part. The delay isn't coming from me."] },
  { name: "Networking Contact", context: "Event small talk", opening: ["Hi, I don't think we've met. What brings you to tonight's event?", "You mentioned you're a student—what kind of work are you interested in?"] },
  { name: "Customer", context: "Support · complaint", opening: ["I've explained this twice and the issue still isn't fixed. Why should I keep waiting?", "This experience has been frustrating. What are you going to do about it?"] },
];

type CoachMessage = { from: "coach" | "user"; text: string };

function AICoach() {
  const [personaIndex, setPersonaIndex] = useState(0);
  const [difficulty, setDifficulty] = useState("Medium");
  const [style, setStyle] = useState("Neutral");
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<CoachMessage[]>([{ from: "coach", text: coachPersonas[0].opening[0] }]);
  const [complete, setComplete] = useState(false);
  const [turns, setTurns] = useState(0);
  const persona = coachPersonas[personaIndex];

  const resetSession = (nextIndex = personaIndex) => {
    const next = coachPersonas[nextIndex];
    setMessages([{ from: "coach", text: next.opening[Math.floor(Math.random() * next.opening.length)] }]);
    setInput(""); setTurns(0); setComplete(false);
  };

  const choosePersona = (index: number) => { setPersonaIndex(index); resetSession(index); };
  const getReply = (answer: string) => {
    const lower = answer.toLowerCase();
    const owns = /responsib|my mistake|i should|i'll own|apolog/.test(lower);
    const clarifies = /clarif|could you|what would|which|can you/.test(lower) || answer.includes("?");
    const solves = /propose|solution|next step|i would|plan|offer|fix/.test(lower);
    const deflects = /not my|their fault|wasn't me|but they|can't/.test(lower);
    const tone = style === "Friendly" ? "That makes sense. " : style === "Demanding" || style === "Difficult" ? "I need a more direct answer. " : style === "Skeptical" ? "I'm not fully convinced yet. " : style === "Busy" ? "Keep it brief. " : "Thanks. ";
    const pressure = difficulty === "Expert" ? "Be precise—I'll challenge any assumption you leave unsupported. " : difficulty === "Hard" ? "I need more evidence before I can agree. " : difficulty === "Easy" ? "Take your time and talk me through it. " : "";
    if (deflects) return `${tone}${pressure}I'm hearing who caused the problem, but not what you personally will do next. How would you take ownership of the outcome?`;
    if (owns && solves) return `${tone}${pressure}That's accountable and action-oriented. What result would tell us your plan worked?`;
    if (clarifies) return `${tone}${pressure}Good question. The priority is protecting the relationship without overpromising. What would you recommend?`;
    if (solves) return `${tone}${pressure}You have a direction. How would you communicate that plan to someone who disagrees?`;
    return `${tone}${pressure}Give me one specific example and the exact first step you would take.`;
  };

  const send = () => {
    const answer = input.trim(); if (!answer || complete) return;
    const nextTurn = turns + 1;
    const withAnswer: CoachMessage[] = [...messages, { from: "user", text: answer }];
    setInput(""); setTurns(nextTurn);
    if (nextTurn >= 3) { setMessages(withAnswer); setComplete(true); return; }
    setMessages([...withAnswer, { from: "coach", text: getReply(answer) }]);
  };

  return (
    <div className="page-stack coach-experience">
      <div className="match-titlebar"><div><div className="eyebrow">INTERACTIVE ROLEPLAY</div><div className="display">AI Career Coach</div><p>Practice the conversation before it counts.</p></div><span className="online"><i /> COACH READY</span></div>
      <div className="coach-settings">
        <label><span>DIFFICULTY</span><select value={difficulty} onChange={(event) => { setDifficulty(event.target.value); resetSession(); }}>{["Easy","Medium","Hard","Expert"].map((item) => <option key={item}>{item}</option>)}</select></label>
        <label><span>PERSONALITY</span><select value={style} onChange={(event) => { setStyle(event.target.value); resetSession(); }}>{["Friendly","Neutral","Demanding","Skeptical","Busy","Difficult"].map((item) => <option key={item}>{item}</option>)}</select></label>
        <div className="session-level"><Icon name="target" /><div><span>SESSION MODE</span><strong>{difficulty} · {style}</strong></div></div>
      </div>
      <div className="interactive-coach-layout">
        <div className="persona-browser"><div className="persona-title"><span>CHOOSE A ROLEPLAY</span><strong>Who do you want to practice with?</strong></div>{coachPersonas.map((item,index) => <button className={personaIndex === index ? "persona-active" : ""} onClick={() => choosePersona(index)} key={item.name}><div className="persona-icon"><Icon name={index % 3 === 0 ? "user" : index % 3 === 1 ? "versus" : "spark"} /></div><div><strong>{item.name}</strong><span>{item.context}</span></div><Icon name="arrow" size={15} /></button>)}</div>
        <div className="roleplay-chat">
          <div className="roleplay-head"><div className="coach-avatar"><Icon name="spark" /></div><div><strong>{persona.name}</strong><span>{persona.context} · {difficulty}</span></div><i /></div>
          <div className="roleplay-messages">{messages.map((message,index) => <div className={`role-message ${message.from}`} key={`${index}-${message.text}`}><span>{message.from === "coach" ? persona.name : "You"}</span><p>{message.text}</p></div>)}{!complete && <div className="intent-hint"><Icon name="spark" /><span>Your coach adapts when you take ownership, ask a question, or propose a solution.</span></div>}</div>
          {!complete ? <div className="roleplay-input"><textarea value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); send(); } }} placeholder="Type what you would say..." /><div><span>Turn {turns + 1} of 3</span><Button onClick={send}>Send response <Icon name="arrow" /></Button></div></div> : <div className="coach-summary"><div className="summary-head"><div className="reveal-burst"><Icon name="spark" /></div><div><span>ROLEPLAY COMPLETE</span><strong>Strong recovery and clear next steps.</strong></div></div><div className="summary-scores">{[["Confidence",84],["Clarity",89],["Professionalism",92],["Empathy",86],["Problem Solving",90]].map(([label,value]) => <div key={label}><span>{label}</span><i><em style={{ width: `${value}%` }} /></i><strong>{value}</strong></div>)}</div><div className="summary-feedback"><div><span>WHAT YOU DID WELL</span><p>You took ownership and moved quickly toward a practical solution.</p></div><div><span>TRY THIS NEXT TIME</span><p>Ask one clarifying question before committing to your plan.</p></div></div><Button onClick={() => resetSession()}>Practice Again <Icon name="arrow" /></Button></div>}
        </div>
      </div>
    </div>
  );
}

const leaders = [
  ["1", "Maya K.", "4,920 XP", "MK"],
  ["2", "Eli R.", "4,780 XP", "ER"],
  ["3", "Sofia T.", "4,610 XP", "ST"],
  ["184", "Jordan Lee", "2,450 XP", "JL"],
  ["185", "Noah B.", "2,435 XP", "NB"],
];

function Leaderboard() {
  return (
    <div className="page-stack">
      <SectionTitle eyebrow="WEEKLY LEAGUE" title="Leaderboard" action={<span className="time-left"><Icon name="clock" size={16} /> Resets in 2d 11h</span>} />
      <div className="podium">
        <div className="podium-player second"><div className="avatar avatar-xl">ER</div><strong>Eli R.</strong><span>4,780 XP</span><div>2</div></div>
        <div className="podium-player first"><Icon name="trophy" /><div className="avatar avatar-xl avatar-alt">MK</div><strong>Maya K.</strong><span>4,920 XP</span><div>1</div></div>
        <div className="podium-player third"><div className="avatar avatar-xl">ST</div><strong>Sofia T.</strong><span>4,610 XP</span><div>3</div></div>
      </div>
      <div className="leader-list">
        {leaders.map(([rank, name, xp, initials]) => (
          <div className={name === "Jordan Lee" ? "leader-row you" : "leader-row"} key={rank}>
            <strong>#{rank}</strong><div className="avatar avatar-small">{initials}</div><span className="grow">{name}{name === "Jordan Lee" && <small>YOU</small>}</span><b>{xp}</b>
          </div>
        ))}
      </div>
    </div>
  );
}

const cosmeticItems = [
  { id: "pitch", name: "Varsity Pitch", category: "Outfit", price: 0, rarity: "OWNED", requirement: "" },
  { id: "casual", name: "Smart Casual", category: "Outfit", price: 350, rarity: "NEW", requirement: "" },
  { id: "formal", name: "The Closer", category: "Outfit", price: 700, rarity: "RARE", requirement: "Reach Level 10" },
  { id: "show", name: "Game Show Glow", category: "Outfit", price: 900, rarity: "LIMITED", requirement: "" },
  { id: "glasses", name: "Round Glasses", category: "Accessories", price: 0, rarity: "OWNED", requirement: "" },
  { id: "phones", name: "Focus Headphones", category: "Accessories", price: 280, rarity: "NEW", requirement: "" },
  { id: "pin", name: "Great Communicator", category: "Accessories", price: 0, rarity: "ACHIEVEMENT", requirement: "Earn Great Communicator badge" },
  { id: "pack", name: "Day One Backpack", category: "Accessories", price: 420, rarity: "RARE", requirement: "" },
  { id: "navy", name: "Midnight Arena", category: "Background", price: 0, rarity: "OWNED", requirement: "" },
  { id: "violet", name: "Violet Voltage", category: "Background", price: 500, rarity: "NEW", requirement: "" },
  { id: "streak", name: "Flame Streak", category: "Background", price: 0, rarity: "STREAK", requirement: "Reach a 30-day streak" },
  { id: "elite", name: "Leaderboard Elite", category: "Background", price: 0, rarity: "RANKED", requirement: "Finish in the weekly top 10" },
];

function AvatarCharacter({ outfit = "Varsity Pitch", accessory = "Round Glasses", background = "Midnight Arena", compact = false }: { outfit?: string; accessory?: string; background?: string; compact?: boolean }) {
  const jacket = outfit === "Game Show Glow" ? "#88f4f5" : outfit === "The Closer" ? "#6e5bd4" : outfit === "Smart Casual" ? "#279ba7" : "#8b72ed";
  const backdrop = background === "Violet Voltage" ? "#2f235c" : background === "Flame Streak" ? "#51251d" : background === "Leaderboard Elite" ? "#3c3516" : "#111a2e";
  return (
    <svg className={`pitch-character ${compact ? "character-compact" : ""}`} viewBox="0 0 280 400" role="img" aria-label="Jordan's customizable PITCH character">
      <rect width="280" height="400" rx="30" fill={backdrop} />
      <path d="M0 310Q70 270 140 310T280 310V400H0Z" fill="#0a0f20" opacity=".65" />
      <circle cx="140" cy="115" r="54" fill="#9d654b" />
      <path d="M87 112Q86 46 145 48Q205 50 193 123L178 90Q135 103 99 80Z" fill="#1a1720" />
      <path d="M109 135q12 10 24 0M151 135q12 10 24 0" fill="none" stroke="#21161a" strokeWidth="4" strokeLinecap="round" />
      <path d="M132 154q10 8 20 0" fill="none" stroke="#6b342d" strokeWidth="4" strokeLinecap="round" />
      <path d="M112 181h56v30h-56z" fill="#8c563f" />
      <path d="M63 263Q68 198 112 190h56q45 10 50 73l-20 83H82Z" fill={jacket} />
      <path d="m112 190 28 42 28-42-8 88h-40Z" fill="#f5f3ee" />
      <path d="m132 207 8 25 8-25-8-8Z" fill="#88f4f5" />
      <path d="M82 250 56 340M198 250l26 90" stroke={jacket} strokeWidth="30" strokeLinecap="round" />
      <path d="M92 344h38v45H76ZM150 344h38l16 45h-54Z" fill="#171d2e" />
      {accessory === "Round Glasses" && <><circle cx="116" cy="126" r="19" fill="none" stroke="#88f4f5" strokeWidth="5" /><circle cx="164" cy="126" r="19" fill="none" stroke="#88f4f5" strokeWidth="5" /><path d="M135 126h10" stroke="#88f4f5" strokeWidth="5" /></>}
      {accessory === "Focus Headphones" && <><path d="M88 118q0-58 52-58t52 58" fill="none" stroke="#88f4f5" strokeWidth="9" /><rect x="80" y="108" width="18" height="45" rx="9" fill="#88f4f5" /><rect x="182" y="108" width="18" height="45" rx="9" fill="#88f4f5" /></>}
      {accessory === "Great Communicator" && <circle cx="187" cy="235" r="11" fill="#88f4f5" />}
      {accessory === "Day One Backpack" && <path d="M75 218q-24 8-19 82h24l8-76Z" fill="#ea874d" />}
    </svg>
  );
}

function ItemTile({ item, owned, equipped, onSelect }: { item: typeof cosmeticItems[number]; owned: boolean; equipped: boolean; onSelect: () => void }) {
  const locked = Boolean(item.requirement);
  return (
    <button className={`cosmetic-tile ${locked ? "cosmetic-locked" : ""} ${equipped ? "cosmetic-equipped" : ""}`} onClick={onSelect}>
      <div className="item-state">{equipped ? "EQUIPPED" : item.rarity}</div>
      <div className={`item-art item-${item.id}`}>
        {item.category === "Outfit" ? <Icon name="user" size={34} /> : item.category === "Accessories" ? <Icon name={item.id === "phones" ? "mic" : "star"} size={34} /> : <Icon name="spark" size={34} />}
      </div>
      <strong>{item.name}</strong>
      {locked ? <span className="lock-reason"><Icon name="clock" size={13} /> {item.requirement}</span> : owned ? <span className="owned-label"><Icon name="check" size={13} /> Owned</span> : <span className="item-price"><Icon name="bolt" size={13} /> {item.price}</span>}
    </button>
  );
}

function CharacterScreen({ equipped, setEquipped, owned, coins, onNavigate }: { equipped: EquippedItems; setEquipped: (value: EquippedItems) => void; owned: string[]; coins: number; onNavigate: (page: Page) => void }) {
  const [tab, setTab] = useState("Outfit");
  const [selected, setSelected] = useState("pitch");
  const visibleItems = cosmeticItems.filter((item) => item.category === tab);
  const selectedItem = cosmeticItems.find((item) => item.id === selected) ?? visibleItems[0];
  const canEquip = owned.includes(selectedItem.id) && !selectedItem.requirement;
  const equipSelected = () => {
    if (!canEquip) return;
    const key = tab === "Outfit" ? "outfit" : tab === "Accessories" ? "accessory" : "background";
    setEquipped({ ...equipped, [key]: selectedItem.name });
  };

  return (
    <div className="page-stack">
      <div className="character-titlebar">
        <div><div className="eyebrow">MY CHARACTER · LEVEL 8</div><div className="display">Make your progress visible.</div><p>Cosmetics are expressive only. They never affect scoring or leaderboard results.</p></div>
        <div className="currency-actions"><div className="coin-wallet"><Icon name="bolt" /><span><strong>{coins.toLocaleString()}</strong>PITCH COINS</span></div><Button variant="secondary" onClick={() => onNavigate("Avatar Shop")}>Visit Shop <Icon name="arrow" /></Button></div>
      </div>
      <div className="character-layout">
        <div className={`character-preview preview-${equipped.background.toLowerCase().replaceAll(" ", "-")}`}>
          <div className="level-flag"><span>LEVEL 8</span><strong>RISING PRO</strong></div>
          <AvatarCharacter {...equipped} />
          <div className="character-identity"><div><strong>Jordan</strong><span>Rising Pro · 2,450 XP</span></div><div className="xp-track"><div className="xp-fill" /></div><small>550 XP to Pro skin</small></div>
        </div>
        <div className="inventory-panel">
          <div className="inventory-tabs">
            {["Outfit", "Accessories", "Background"].map((item) => <button className={tab === item ? "inventory-tab-active" : ""} onClick={() => { setTab(item); setSelected(cosmeticItems.find((cosmetic) => cosmetic.category === item)?.id ?? "pitch"); }} key={item}>{item}</button>)}
          </div>
          <div className="inventory-top"><span>{visibleItems.length} ITEMS</span><span><i /> Owned <i /> Locked</span></div>
          <div className="cosmetic-grid">
            {visibleItems.map((item) => <ItemTile item={item} owned={owned.includes(item.id)} equipped={equipped.outfit === item.name || equipped.accessory === item.name || equipped.background === item.name} onSelect={() => setSelected(item.id)} key={item.id} />)}
          </div>
          <div className="equip-bar">
            <div><span>SELECTED</span><strong>{selectedItem.name}</strong><small>{selectedItem.requirement || (owned.includes(selectedItem.id) ? "Ready to equip" : `${selectedItem.price} PITCH Coins`)}</small></div>
            {canEquip ? <Button onClick={equipSelected}>Equip Item <Icon name="check" /></Button> : <Button variant="secondary" onClick={() => onNavigate("Avatar Shop")}>{selectedItem.requirement ? "View Requirement" : "Get in Shop"} <Icon name="arrow" /></Button>}
          </div>
        </div>
      </div>
      <div className="milestone-strip">
        <div className="milestone-current"><Icon name="check" /><span><small>LEVEL 5</small>Rising Pro skin</span></div>
        <i />
        <div><span><small>LEVEL 10</small>Pro skin</span></div>
        <i />
        <div><span><small>LEVEL 20</small>Elite skin</span></div>
        <i />
        <div><Icon name="trophy" /><span><small>LEVEL 30</small>Legend skin</span></div>
      </div>
    </div>
  );
}

function AvatarShop({ coins, owned, onBuy, onNavigate }: { coins: number; owned: string[]; onBuy: (id: string, price: number) => void; onNavigate: (page: Page) => void }) {
  const [filter, setFilter] = useState("All");
  const [unlocked, setUnlocked] = useState<typeof cosmeticItems[number] | null>(null);
  const shopItems = cosmeticItems.filter((item) => item.price > 0 && (filter === "All" || item.category === filter));
  const buy = (item: typeof cosmeticItems[number]) => {
    if (item.requirement || owned.includes(item.id) || coins < item.price) return;
    onBuy(item.id, item.price);
    setUnlocked(item);
  };
  return (
    <div className="page-stack">
      <div className="shop-hero">
        <div><button className="back-link" onClick={() => onNavigate("Character")}><Icon name="arrow" /> Back to Character</button><div className="eyebrow">PITCH LOCKER</div><div className="display">Earn it. Own it. Show it.</div><p>No real money. Every Coin comes from showing up, practicing, and competing.</p></div>
        <div className="shop-wallet"><Icon name="bolt" size={30} /><div><span>YOUR BALANCE</span><strong>{coins.toLocaleString()}</strong><small>PITCH Coins</small></div></div>
      </div>
      <div className="earn-coins">
        <strong>Earn more Coins</strong>
        <span><Icon name="play" /> Complete scenario <b>+40</b></span>
        <span><Icon name="fire" /> Daily streak <b>+25</b></span>
        <span><Icon name="versus" /> Head-to-Head win <b>+100</b></span>
        <Button variant="ghost" onClick={() => onNavigate("Practice")}>Start practicing <Icon name="arrow" /></Button>
      </div>
      <div className="shop-controls">
        <div className="inventory-tabs">{["All", "Outfit", "Accessories", "Background"].map((item) => <button className={filter === item ? "inventory-tab-active" : ""} onClick={() => setFilter(item)} key={item}>{item}</button>)}</div>
        <span>{shopItems.length} ITEMS</span>
      </div>
      <div className="shop-grid">
        {shopItems.map((item) => (
          <div className={`shop-item ${owned.includes(item.id) ? "shop-owned" : ""}`} key={item.id}>
            <div className="shop-art"><div className={`item-art item-${item.id}`}><Icon name={item.category === "Outfit" ? "user" : item.category === "Accessories" ? "star" : "spark"} size={44} /></div><span>{owned.includes(item.id) ? "OWNED" : item.rarity}</span></div>
            <div className="shop-item-info"><div><span>{item.category}</span><strong>{item.name}</strong></div><Button variant={owned.includes(item.id) ? "secondary" : "primary"} onClick={() => buy(item)}>{owned.includes(item.id) ? <><Icon name="check" /> Owned</> : <><Icon name="bolt" /> {item.price}</>}</Button></div>
          </div>
        ))}
      </div>
      {unlocked && <div className="unlock-overlay" onClick={() => setUnlocked(null)}><div className="unlock-modal" onClick={(event) => event.stopPropagation()}><div className="unlock-rays" /><div className="unlock-kicker">NEW ITEM UNLOCKED</div><div className={`unlock-art item-art item-${unlocked.id}`}><Icon name={unlocked.category === "Outfit" ? "user" : unlocked.category === "Accessories" ? "star" : "spark"} size={64} /></div><div className="display">{unlocked.name}</div><p>{unlocked.category} added to your character locker.</p><Button onClick={() => { setUnlocked(null); onNavigate("Character"); }}>Customize now <Icon name="arrow" /></Button></div></div>}
    </div>
  );
}

function Profile({ onNavigate, equipped, profile, onSave }: { onNavigate: (page: Page) => void; equipped: EquippedItems; profile: ProfileData; onSave: (profile: ProfileData) => void }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(profile);
  const beginEdit = () => { setDraft(profile); setEditing(true); };
  const save = () => { onSave(draft); setEditing(false); };
  return (
    <div className="page-stack">
      <div className="profile-hero">
        <div className="profile-character"><AvatarCharacter compact {...equipped} /><span className="profile-photo">{profile.avatar.startsWith("http") ? <img src={profile.avatar} alt="" /> : profile.avatar}</span></div>
        <div><div className="eyebrow">RISING PRO · LEVEL 8</div><div className="display">{profile.name}</div><p>{profile.schoolMajor} · {profile.locationBio}</p></div>
        <div className="profile-actions"><Button onClick={() => onNavigate("Character")}>Customize Character <Icon name="arrow" /></Button><Button variant="secondary" onClick={beginEdit}>Edit profile</Button></div>
      </div>
      {editing && (
        <div className="profile-editor">
          <div className="editor-head"><div><div className="eyebrow">EDIT PROFILE</div><div className="heading">Make it yours</div></div><button className="icon-button" onClick={() => setEditing(false)} aria-label="Cancel editing"><Icon name="close" /></button></div>
          <div className="profile-fields">
            <label><span>Name</span><input value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} /></label>
            <label><span>Avatar initials or photo URL</span><input value={draft.avatar} onChange={(event) => setDraft({ ...draft, avatar: event.target.value })} /></label>
            <label><span>School / major</span><input value={draft.schoolMajor} onChange={(event) => setDraft({ ...draft, schoolMajor: event.target.value })} /></label>
            <label><span>Location / bio line</span><input value={draft.locationBio} onChange={(event) => setDraft({ ...draft, locationBio: event.target.value })} /></label>
          </div>
          <div className="editor-actions"><Button variant="ghost" onClick={() => setEditing(false)}>Cancel</Button><Button onClick={save}><Icon name="check" /> Save changes</Button></div>
        </div>
      )}
      <div className="profile-grid">
        <div className="panel"><SectionTitle eyebrow="SKILL MAP" title="Your strengths" />{[["Adaptability",92],["Clarity",86],["Problem-solving",84],["Confidence",79],["Professionalism",88]].map(([label, score]) => <div className="skill-row" key={label}><span>{label}</span><div><i style={{ width: `${score}%` }} /></div><strong>{score}</strong></div>)}</div>
        <div className="panel"><SectionTitle eyebrow="TROPHY CASE" title="Badges" /><div className="badge-grid">{[["fire","12 Day Streak"],["star","Clear Thinker"],["trophy","Top 20%"],["bolt","Quick Draw"]].map(([icon,label]) => <div className="badge" key={label}><Icon name={icon as IconName} /><span>{label}</span></div>)}</div></div>
      </div>
    </div>
  );
}

function App() {
  const [page, setPage] = useState<Page>("Dashboard");
  const [menuOpen, setMenuOpen] = useState(false);
  const [coins, setCoins] = useState(1240);
  const [owned, setOwned] = useState(["pitch", "glasses", "navy"]);
  const [equipped, setEquipped] = useState<EquippedItems>({ outfit: "Varsity Pitch", accessory: "Round Glasses", background: "Midnight Arena" });
  const [profile, setProfile] = useState<ProfileData>({ name: "Jordan Lee", avatar: "JL", schoolMajor: "Business student", locationBio: "Chicago, IL" });

  const buyItem = (id: string, price: number) => {
    if (coins < price || owned.includes(id)) return;
    setCoins((value) => value - price);
    setOwned((items) => [...items, id]);
  };

  const content = {
    Home: <Home onNavigate={setPage} />,
    Dashboard: <Dashboard onNavigate={setPage} equipped={equipped} />,
    Practice: <Practice />,
    "Head-to-Head": <HeadToHead />,
    "AI Coach": <AICoach />,
    Leaderboard: <Leaderboard />,
    Profile: <Profile onNavigate={setPage} equipped={equipped} profile={profile} onSave={setProfile} />,
    Character: <CharacterScreen equipped={equipped} setEquipped={setEquipped} owned={owned} coins={coins} onNavigate={setPage} />,
    "Avatar Shop": <AvatarShop coins={coins} owned={owned} onBuy={buyItem} onNavigate={setPage} />,
  }[page];

  return (
    <div className="app-shell">
      <Sidebar page={page} onNavigate={setPage} open={menuOpen} onClose={() => setMenuOpen(false)} profile={profile} />
      {menuOpen && <div className="backdrop" onClick={() => setMenuOpen(false)} />}
      <main className="main">
        <header className="topbar">
          <button className="icon-button mobile-only" onClick={() => setMenuOpen(true)} aria-label="Open menu"><Icon name="menu" /></button>
          <div className="mobile-only"><Logo /></div>
          <div className="topbar-right">
            <button className="topbar-coins" onClick={() => setPage("Avatar Shop")}><Icon name="bolt" size={16} /><strong>{coins.toLocaleString()}</strong><span>COINS</span></button>
            <div className="streak-chip"><Icon name="fire" size={17} /><span>12</span></div>
            <button className="icon-button" aria-label="Notifications"><Icon name="bell" /><i /></button>
            <div className="avatar avatar-small">{profile.avatar.startsWith("http") ? <img src={profile.avatar} alt="" /> : profile.avatar}</div>
          </div>
        </header>
        <div className="page-content">{content}</div>
      </main>
    </div>
  );
}

export default App;
